// Schnorr2 project doc.go

/*
Schnorr2 document
*/
package main
