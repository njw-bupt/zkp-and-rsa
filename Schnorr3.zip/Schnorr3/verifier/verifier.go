package verifier

import (
	"Schnorr2/myprime"
	"fmt"
	"math"
	"math/rand"
)

type Verifier struct {
	P int
	V int
	G int
}

func (b *Verifier) Gen_e(t float64) int {
	ee := math.Pow(2, t)
	eee := int(ee)
	e := rand.Intn(eee) + 1
	return e
}

func (b *Verifier) Check(x int, e int, y int) bool {
	var left, right int
	left = myprime.ModPow(b.G, y, b.P)
	right = myprime.ModPow(b.V, e, b.P)
	right = myprime.ModPow(x*right, 1, b.P)
	fmt.Println("left=", left, "right=", right)
	if left == right {
		return true
	} else {
		return false
	}
}
