package prover

import (
	"Schnorr2/myprime"
	"math"
	"math/rand"
	"time"
)

type Prover struct {
	P           int
	Q           int
	S           int
	V           int
	G           int
	ArrivalTime int64
}

func Gen_p() int {
	mp := new(myprime.MyPrime)
	mp.Init()
	var p int
	for {
		num1 := rand.Intn(mp.GetPrimeNum())
		p = int(mp.GetPrime(num1))
		if p > 100 {
			break
		}
	}
	return p
}

func Gen_q(p int) int {
	q := (p - 1) * (rand.Intn(100) + 1)
	return q
}

func (a *Prover) Gen_g() {
	a.G = rand.Intn(1000) + 100
}

func (a *Prover) Gen_s() {
	a.S = rand.Intn(a.Q)
}

func (a *Prover) Gen_v() {
	a.V = myprime.ModPow(a.G, a.S, a.P)
}

func (a *Prover) Gen_r() int {
	var r int
	r = rand.Intn(a.Q-1) + 1
	return r
}

func (a *Prover) Gen_x(r int) int {
	x := myprime.ModPow(a.G, r, a.P)
	return x
}

func (a *Prover) Gen_y(e int, r int) int {
	y := myprime.ModPow(a.S*e+r, 1, a.Q)
	return y
}

func Get_currentTime() int64 {
	t1 := time.Now()
	timestamp1 := t1.UnixNano() / 1000
	return timestamp1
}

func Gen_poissonTime(beta float64) float64 {
	x := rand.Float64()
	ln := math.Log(x)
	t := beta * ln
	t = -t
	return t
}

func (this *Prover) Less(other interface{}) bool {
	return this.ArrivalTime < other.(*Prover).ArrivalTime
}

func Delay(t int64) {
	t1 := Get_currentTime()
	for Get_currentTime() < t1+t {

	}
}
