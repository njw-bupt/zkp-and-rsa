package verifier

import (
	"F_S/myprime"
	"fmt"
	//	"math"
	"math/rand"
)

type Verifier struct {
	N int
	V int
}

func (b *Verifier) Gen_e() int {
	e := rand.Intn(2)
	return e
}

func (b *Verifier) Check(x int, e int, y int) bool {
	var left, right int
	left = myprime.ModPow(y, 2, b.N)
	right = myprime.ModPow(b.V, e, b.N)
	right = myprime.ModPow(x*right, 1, b.N)

	fmt.Println("left=", left, "right=", right)
	if left == right {
		return true
	} else {
		return false
	}
}
