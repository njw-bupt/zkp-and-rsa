// F_S project doc.go

/*
F_S document
*/
package main
