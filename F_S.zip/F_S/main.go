// F_S project main.go
package main

import (
	//	"F_S/myprime"
	"F_S/prover"
	"F_S/verifier"
	"fmt"
	"math/rand"
	//"os"
	"time"

	"github.com/gansidui/priority_queue"
)

func main() {
	/*
		userFile := "result.txt"
		fout, err := os.Create(userFile)
		defer fout.Close()
		if err != nil {
			fmt.Println(userFile, err)
			return
		}
	*/
	rand.Seed(time.Now().UnixNano())

	startTime := prover.Get_currentTime()
	fmt.Println("start time ", startTime)
	//初始化

	mq := priority_queue.New()

	//生成泊松业务流mq
	for i := 0; i < 1; i++ {

		var Alice prover.Prover
		n := prover.Gen_n()
		Alice.N = n
		Alice.Gen_s()
		fmt.Print("n=", Alice.N)
		fmt.Println("private key=", Alice.S)
		Alice.Gen_v()
		fmt.Println("public key=", Alice.V)
		Alice.ArrivalTime = int64(prover.Gen_poissonTime(5)) + prover.Get_currentTime()
		fmt.Println("arrival time= ", Alice.ArrivalTime)

		mq.Push(&Alice)
	}
	var checkRes bool
	for mq.Len() > 0 {

		Alice := mq.Pop().(*prover.Prover)
		fmt.Println("队列元素 ", Alice.ArrivalTime)

		for Alice.ArrivalTime > prover.Get_currentTime() {

		}
		startTime1 := prover.Get_currentTime()

		var Bob verifier.Verifier
		Bob.N = Alice.N
		Bob.V = Alice.V

		//验证开始
		var checkA bool
		for i := 0; i < 3; i++ {
			fmt.Println("i=", i)
			//第一阶段
			r := Alice.Gen_r()
			fmt.Println("r=", r)
			x := Alice.Gen_x(r)
			fmt.Println("proof x=", x)
			prover.Delay(10000)
			//第二阶段
			e := Bob.Gen_e()
			fmt.Println("question e=", e)
			prover.Delay(10000)
			//第三阶段
			y := Alice.Gen_y(e, r)
			fmt.Println("response y=", y)
			prover.Delay(10000)
			//验证
			checkA = Bob.Check(x, e, y)
			fmt.Println("result =", checkA, "\n")
			if checkA == false {
				fmt.Println("error Alice")
				checkRes = false
				break
			} else {
				checkRes = true
			}
		}
		fmt.Println("final check result ", checkRes)
		endTime1 := prover.Get_currentTime()
		tt := int(endTime1 - startTime1)
		//ttt := string(tt)
		fmt.Println("deal time ", tt)

		//fout.WriteString(ttt)
		//fout.Write(b_buf.Bytes())

	}
	endTime := prover.Get_currentTime()
	fmt.Println("running time of the whole program ", endTime-startTime)
}
