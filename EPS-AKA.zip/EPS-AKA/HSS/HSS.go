package HSS

import (
	"EPS-AKA/F2"
	"math/rand"
)

type HSS struct {
	k    [16]int
	Rand [16]int
	xres [8]int
}

func (h *HSS) Setk(k [16]int) {
	h.k = k
}

func (h *HSS) Gen_rand() {
	//h.Rand = [16]int{0x53, 0x37, 0x06, 0x9d, 0xa8, 0x27, 0xb2, 0x4c, 0x5d, 0xec, 0x9f, 0xeb, 0xe8, 0xaf, 0xf7, 0xea}
	//h.Rand = [16]int{83, 55, 6, 157, 168, 39, 178, 76, 93, 236, 159, 235, 232, 175, 247, 234}
	for i := 0; i < 16; i++ {
		h.Rand[i] = rand.Intn(256)
	}
}

func (h *HSS) Gen_xres() {
	var op_c [16]int
	var temp [16]int
	var out [16]int
	var rijndaelInput [16]int
	var i int
	k := h.k
	F2.RijndaelKeySchedule(&k)
	F2.ComputeOPc(&op_c)

	for i = 0; i < 16; i++ {
		rijndaelInput[i] = h.Rand[i] ^ op_c[i]
	}

	F2.RijndaelEncrypt(&rijndaelInput, &temp)

	for i = 0; i < 16; i++ {
		rijndaelInput[i] = temp[i] ^ op_c[i]
	}
	rijndaelInput[15] ^= 1

	F2.RijndaelEncrypt(&rijndaelInput, &out)
	for i = 0; i < 16; i++ {
		out[i] ^= op_c[i]
	}
	//var res [8]int

	for i = 0; i < 8; i++ {
		h.xres[i] = out[i+8]
	}
}

func (h *HSS) Judge(res [8]int) bool {
	var r bool
	for i := 0; i < 8; i++ {
		if res[i] != h.xres[i] {
			r = false
			break
		} else {
			r = true
		}
	}
	return r
}
