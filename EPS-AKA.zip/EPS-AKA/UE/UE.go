package UE

import (
	"EPS-AKA/F2"
)

type UE struct {
	k   [16]int
	Res [8]int
}

func (u *UE) Setk(k [16]int) {
	u.k = k
}

func (u *UE) Gen_res(rand [16]int) {
	var op_c [16]int
	var temp [16]int
	var out [16]int
	var rijndaelInput [16]int
	var i int
	k := u.k
	F2.RijndaelKeySchedule(&k)
	F2.ComputeOPc(&op_c)

	for i = 0; i < 16; i++ {
		rijndaelInput[i] = rand[i] ^ op_c[i]
	}

	F2.RijndaelEncrypt(&rijndaelInput, &temp)

	for i = 0; i < 16; i++ {
		rijndaelInput[i] = temp[i] ^ op_c[i]
	}
	rijndaelInput[15] ^= 1

	F2.RijndaelEncrypt(&rijndaelInput, &out)
	for i = 0; i < 16; i++ {
		out[i] ^= op_c[i]
	}

	for i = 0; i < 8; i++ {
		u.Res[i] = out[i+8]
	}
}
