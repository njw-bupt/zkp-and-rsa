// EPS-AKA project main.go
package main

import (
	"EPS-AKA/HSS"
	"EPS-AKA/UE"
	"fmt"
	"math/rand"
	"time"
)

func main() {
	startTime := time.Now()
	timestamp1 := startTime.UnixNano() / 1000

	rand.Seed(time.Now().UnixNano())
	var u1 UE.UE
	var h1 HSS.HSS
	k := [16]int{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}
	u1.Setk(k)
	h1.Setk(k)

	h1.Gen_rand()
	u1.Gen_res(h1.Rand)
	h1.Gen_xres()
	if h1.Judge(u1.Res) == true {
		fmt.Println("check success!!")
	}
	for i := 0; i < 8; i++ {
		fmt.Printf("%x", u1.Res[i])
	}
	fmt.Println("")

	endTime := time.Now()
	timestamp2 := endTime.UnixNano() / 1000
	fmt.Println("deal time:", (timestamp2 - timestamp1))
}
