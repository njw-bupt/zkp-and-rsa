// F_F_S2 project main.go
package main

import (
	"F_F_S2/prover"
	"F_F_S2/verifier"
	"fmt"
	"math/rand"
	//"os"
	"time"

	"github.com/gansidui/priority_queue"
)

func main() {
	/*
		userFile := "result.txt"
		fout, err := os.Create(userFile)
		defer fout.Close()
		if err != nil {
			fmt.Println(userFile, err)
			return
		}
	*/

	rand.Seed(time.Now().UnixNano())

	startTime := prover.Get_currentTime()
	fmt.Println("start time ", startTime)
	//初始化

	mq := priority_queue.New()

	//生成泊松业务流mq
	for i := 0; i < 1; i++ {

		var Alice prover.Prover
		n := prover.Gen_n()
		Alice.N = n
		fmt.Println("n=", Alice.N)

		Alice.Gen_s()
		fmt.Print("private key:", "\t")
		k := len(Alice.S)
		for i := 0; i < k; i++ {
			fmt.Print(Alice.S[i], "\t")
		}
		fmt.Print("\n")

		Alice.Gen_v()
		fmt.Print("public key:", "\t")
		for i := 0; i < k; i++ {
			fmt.Print(Alice.V[i], "\t")
		}
		fmt.Print("\n")

		Alice.ArrivalTime = int64(prover.Gen_poissonTime(5)) + prover.Get_currentTime()
		fmt.Println("arrival time= ", Alice.ArrivalTime)

		mq.Push(&Alice)

	}

	var checkRes bool

	for mq.Len() > 0 {

		Alice := mq.Pop().(*prover.Prover)
		fmt.Println("队列元素 ", Alice.ArrivalTime)

		for Alice.ArrivalTime > prover.Get_currentTime() {

		}
		startTime1 := prover.Get_currentTime()

		var Bob verifier.Verifier
		Bob.N = Alice.N
		k := len(Alice.V)
		for i := 0; i < k; i++ {
			Bob.V[i] = Alice.V[i]
		}

		for t := 0; t < 3; t++ {
			fmt.Println("t=", t)
			//第一阶段
			r := Alice.Gen_r()
			fmt.Println("r=", r)
			x := Alice.Gen_x(r)
			fmt.Println("proof x=", x)
			prover.Delay(10000)
			//第二阶段
			Bob.Gen_e()
			fmt.Print("question e:", "\t")
			for i := 0; i < k; i++ {
				fmt.Print(Bob.E[i], "\t")
			}
			fmt.Print("\n")
			prover.Delay(10000)
			//第三阶段
			//y := Alice.Gen_y(Bob.E, k, r)
			y := Alice.Gen_y(Bob.E[:], r)
			fmt.Println("response y=", y)
			prover.Delay(10000)
			//验证
			res := Bob.Check(x, Bob.E[:], y)
			fmt.Println("result =", res, "\n")
			if res == false {
				fmt.Println("error Alice")
				checkRes = false
				break
			} else {
				checkRes = true
			}

		}

		fmt.Println("final check result ", checkRes)
		endTime1 := prover.Get_currentTime()
		tt := int(endTime1 - startTime1)
		fmt.Println("deal time ", tt)
		/*
			ttt := string(tt)
			fmt.Println("deal time ", tt)

			fout.WriteString(ttt)
		*/
	}
	endTime := prover.Get_currentTime()
	fmt.Println("running time of the whole program ", endTime-startTime)
}
