package prover

import (
	"F_F_S2/myprime"

	"math"
	"math/rand"
	"time"
)

type Prover struct {
	N int

	S           [3]int //private key
	V           [3]int //public key
	ArrivalTime int64
}

func Gen_n() int {
	mp := new(myprime.MyPrime)
	mp.Init()
	var p int
	var q int
	for {
		num1 := rand.Intn(mp.GetPrimeNum())
		num2 := rand.Intn(mp.GetPrimeNum())

		p = int(mp.GetPrime(num1))
		//fmt.Println("p=", p)

		q = int(mp.GetPrime(num2))
		//fmt.Println("q=", q)
		if p > 100 && q > 100 {
			break
		}
	}

	n := p * q
	return n
}
func (a *Prover) Gen_s() {

	for i := 0; i < len(a.S); i++ {

		var s int
		s = 1
		for a.N%s == 0 || s > (a.N-1) {
			mp := new(myprime.MyPrime)
			mp.Init()
			num1 := rand.Intn(mp.GetPrimeNum())
			s = int(mp.GetPrime(num1))
		}
		a.S[i] = s
	}
}

func (a *Prover) Gen_v() {
	for i := 0; i < len(a.V); i++ {
		a.V[i] = myprime.ModPow(a.S[i], 2, a.N)
	}
}

func (a *Prover) Gen_r() int {
	r := rand.Intn(a.N-1) + 1
	return r
}

func (a *Prover) Gen_x(r int) int {
	var x int
	x = r * r
	x = myprime.ModPow(x, 1, a.N)
	return x
}

func (a *Prover) Gen_y(e []int, r int) int {
	y := 1
	for i := 0; i < len(e); i++ {
		yi := myprime.ModPow(a.S[i], e[i], a.N)
		y = y * yi
	}
	y = myprime.ModPow(r*y, 1, a.N)
	return y
}

func Get_currentTime() int64 {
	t1 := time.Now()
	timestamp1 := t1.UnixNano() / 1000
	return timestamp1
}

func Gen_poissonTime(beta float64) float64 {
	x := rand.Float64()
	ln := math.Log(x)
	t := beta * ln
	t = -t
	return t
}

func (this *Prover) Less(other interface{}) bool {
	return this.ArrivalTime < other.(*Prover).ArrivalTime
}
func Delay(t int64) {
	t1 := Get_currentTime()
	for Get_currentTime() < t1+t {

	}
}
