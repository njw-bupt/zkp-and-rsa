package verifier

import (
	"F_F_S2/myprime"
	"fmt"
	"math/rand"
)

type Verifier struct {
	N int
	V [3]int
	E [3]int
}

func (b *Verifier) Gen_e() {
	for i := 0; i < len(b.E); i++ {
		b.E[i] = rand.Intn(2)
	}
}

func (b *Verifier) Check(x int, e []int, y int) bool {
	var left, right int
	right = 1
	left = myprime.ModPow(y, 2, b.N)
	for i := 0; i < len(e); i++ {
		righti := myprime.ModPow(b.V[i], e[i], b.N)
		right = right * righti
	}
	right = myprime.ModPow(x*right, 1, b.N)
	fmt.Println("left=", left, "right=", right)
	if left == right {
		return true
	} else {
		return false
	}
}
